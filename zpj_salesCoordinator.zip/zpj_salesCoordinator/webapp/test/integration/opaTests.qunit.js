/* global QUnit */

sap.ui.require(["prj/salescoordinator/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
