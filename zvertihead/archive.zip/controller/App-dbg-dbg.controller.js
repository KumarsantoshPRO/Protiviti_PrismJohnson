sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("zpj.pro.sd.sk.zprovertihead.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  