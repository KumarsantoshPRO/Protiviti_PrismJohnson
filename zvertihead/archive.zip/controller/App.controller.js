sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("zpj.pro.sd.sk.zprovertihead.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map