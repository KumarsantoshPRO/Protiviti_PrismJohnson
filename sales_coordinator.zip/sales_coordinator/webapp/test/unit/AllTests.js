sap.ui.define([
	"prj/sales_coordinator/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
